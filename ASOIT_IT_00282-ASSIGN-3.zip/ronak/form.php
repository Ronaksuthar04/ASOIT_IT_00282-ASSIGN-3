<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ronak";
$successMessage = "";
$errorMessage = "";
$successConn="";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    $successConn="Connection Established!!";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $contactno = $_POST['contactno'];
    $age = $_POST['age'];
    $msg = $_POST['msg'];

    if (!empty($fname) && !empty($lname) && !empty($email) && !empty($contactno) && !empty($age) && !empty($msg)) {
        $sql = "INSERT INTO feedback (fname, lname, email, contactno, age, msg) VALUES ('$fname', '$lname', '$email', '$contactno', '$age', '$msg')";

        if ($conn->query($sql) === TRUE) {
            $successMessage = "New record created successfully";
            header("Location: response.html");
            exit(); 
        } else {
            $errorMessage = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $errorMessage = "Please fill in all the fields";
    }
}
$conn->close();
?>

